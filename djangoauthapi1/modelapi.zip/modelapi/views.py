from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser
import tensorflow as tf
from PIL import Image
import numpy as np
import os
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

CLASS_NAMES = ['Ballet Flat', 'Boat', 'Brogue', 'Clog', 'Sneaker']

class H5ModelPredictionView(APIView):
    parser_classes = [MultiPartParser]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        try:
            model_path = os.path.join(settings.BASE_DIR, 'modelapi', 'model', 'thezaack.h5')
            logger.info(f"Loading model from: {model_path}")

            self.model = tf.keras.models.load_model(model_path, compile=False)
            logger.info("Model loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            self.model = None

    def post(self, request, *args, **kwargs):
        if not self.model:
            logger.error("Model is not loaded.")
            return Response({'error': 'Model not loaded'}, status=500)

        image_file = request.FILES.get('image')
        if not image_file:
            logger.error("No image file found in request.")
            return Response({'error': 'No image provided'}, status=400)

        try:
            logger.info(f"Received image: {image_file.name}, size: {image_file.size}")

            image = Image.open(image_file).convert('RGB')
            image = image.resize((224, 224))
            image_array = np.array(image) / 255.0
            image_array = np.expand_dims(image_array, axis=0)

            logger.info("Preprocessed image. Starting prediction...")

            predictions = self.model.predict(image_array)
            predicted_index = int(np.argmax(predictions[0]))
            logger.info(f"Raw prediction output: {predictions}")
            logger.info(f"Predicted index: {predicted_index}")

            if predicted_index < 0 or predicted_index >= len(CLASS_NAMES):
                logger.error(f"Predicted index {predicted_index} out of range.")
                return Response({'error': 'Prediction index out of range'}, status=500)

            predicted_class = CLASS_NAMES[predicted_index]
            logger.info(f"Predicted class: {predicted_class}")

            return Response({'class_name': predicted_class})

        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return Response({'error': f'Prediction failed: {str(e)}'}, status=500)
